/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class distance extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException{
        res.setContentType("text/html");
        PrintWriter pw=res.getWriter();
        
         float value=Float.parseFloat(req.getParameter("value"));
        String op=req.getParameter("option");
        if(op.equals("miles")){
            pw.print(value+" KMs = "+(value*0.621371f)+" Miles");
        }
        else if(op.equals("meters")){
            pw.print(value+" KMs = "+(value*1000)+" Meters");
        }
        else if(op.equals("feets")){
         pw.print(value+" KMs = "+(value*3280.839895f)+" Feets");
        }
        else{
            pw.print("Invalid");
        }
    }

}
