/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class user_sub extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException{
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();
        Calendar c = Calendar.getInstance();
        try{
            String a,b;
            a=req.getParameter("username");
            b=req.getParameter("subject");
   
           out.println("Hello "+a+" your fav sub is "+b+"</br>curr time is "+c.getTime());
           
            
        }
        finally{
        out.close();
        }
    }

}
