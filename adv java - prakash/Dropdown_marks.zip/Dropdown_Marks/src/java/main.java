/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class main extends HttpServlet {
protected void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException{
PrintWriter pw= res.getWriter();
res.setContentType("text/html");
try{
int a,b;
String s1,s2;
a=Integer.parseInt(req.getParameter("marks_sub1"));
b=Integer.parseInt(req.getParameter("marks_sub2"));
float c=(a+b)/200f;
float d=c*100f;
s1=req.getParameter("s1");
s2=req.getParameter("s2");
String op=(req.getParameter("type"));
if(op.equals("1")){
    pw.print("Sum of Marks is: "+(a+b));
}
else if (op.equals("2")){
    pw.print("Average of marks is :"+((a+b)/2));
}
else if(op.equals("3")){
    pw.print("The Percentage is : "+d);
}
else{
pw.println("Error");
}
}catch(Exception e){pw.println("e");}finally{pw.close();}
}
}